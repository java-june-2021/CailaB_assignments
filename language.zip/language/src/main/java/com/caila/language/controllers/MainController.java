package com.caila.language.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.caila.language.models.Language;
import com.caila.language.services.LanguageService;

@Controller
public class MainController {
//	@Autowired
	private final LanguageService lService;
	public MainController(LanguageService service) {
		this.lService = service;
	}
	
	// base url for displaying our languages and form
	
	@GetMapping("/")
	public String index(Model viewModel, @ModelAttribute("language") Language language) {
		viewModel.addAttribute("allLanguages", this.lService.allLanguages());
		return "index.jsp";
	}
	// checked
	
	@PostMapping("/")
	public String addLanguage(@Valid @ModelAttribute("language") Language language, BindingResult result, Model viewModel) {
		if(result.hasErrors()) {
			viewModel.addAttribute("allLanguages", this.lService.allLanguages()); //index renders with errors. need to show whatwe want + errors
			return "index.jsp";
		}
		this.lService.createLanguage(language);
		return "redirect:/";
	}
	//checked
	
	@GetMapping("/{id}")
	public String showLanguage(Model viewModel, @PathVariable("id") Long id) {
		viewModel.addAttribute("oneLanguage", this.lService.getOneLanguage(id));
		return "show.jsp";
	}
	//checked
	
	@GetMapping("/{id}/edit")
	public String updateLanguage(Model viewModel, @PathVariable("id") Long id) {
		viewModel.addAttribute("language", this.lService.getOneLanguage(id));
		return "edit.jsp";
	}
	
	//checked

	@PutMapping("/{id}/edit")
	public String updateLanguage(@Valid @ModelAttribute("language") Language language, BindingResult result, Model viewModel, @PathVariable("id") Long id) {
		if(result.hasErrors()) {
		viewModel.addAttribute("language", this.lService.getOneLanguage(id));
		return "edit.jsp";
		}
		this.lService.updateLanguage(language);
	return "redirect:/{id}";
	}
	//checked
	
	@DeleteMapping("/{id}/delete")
	public String deleteLanguage(@PathVariable("id") Long id) {
		this.lService.deleteLanguage(id);
		return "redirect:/";
	}
	//checked

}
