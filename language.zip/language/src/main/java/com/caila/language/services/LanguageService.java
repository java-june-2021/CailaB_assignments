package com.caila.language.services;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.caila.language.models.Language;
import com.caila.language.repositories.LanguageRepository;

@Service
public class LanguageService {
	private final LanguageRepository lRepository;
	
	public LanguageService(LanguageRepository lRepo) {
		this.lRepository = lRepo;
	}
	//find all 
	public List<Language> allLanguages(){
		return this.lRepository.findAll();
	}
	//find one. need .orElse(null) to work
	public Language getOneLanguage(Long id) {
		return this.lRepository.findById(id).orElse(null);
	}
	//create
	public Language createLanguage(Language language) {
		return this.lRepository.save(language);
	}
	
	//update 
	public Language updateLanguage(Language updatedLang) {
		return this.lRepository.save(updatedLang);
	}
	
	//delete. no return because void
	public void deleteLanguage(Long id) {
		this.lRepository.deleteById(id);
	}
}
