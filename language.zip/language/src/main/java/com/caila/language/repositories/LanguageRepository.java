package com.caila.language.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.caila.language.models.Language;

@Repository
public interface LanguageRepository extends CrudRepository<Language, Long>{
	//retrieves all the languages from the database
	List<Language> findAll(); //same as when in mysql type SELECT * FROM language
	//finds a language by the creator
	List<Language> findByCreatorContaining(String search);
	//counts how many names contain certain string
	Long countByNameContaining(String search);
	//deletes a language that starts with specific name.
	Long deleteByNameStartingWith(String search);
}
