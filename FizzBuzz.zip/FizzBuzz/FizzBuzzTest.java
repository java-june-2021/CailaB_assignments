public class FizzBuzzTest {
    public static void main(String[] args){
        FizzBuzz newfb = new FizzBuzz();
        newfb.counter();
    }
}