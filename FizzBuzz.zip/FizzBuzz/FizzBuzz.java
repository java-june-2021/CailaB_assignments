public class FizzBuzz {
    public String fizzBuzz(int number){
        if(number % 3 == 0 && number % 5 == 0){
            return "FizzBuzz";
        } else if (number % 3 == 0){
            return "Fizz";
        } else if (number % 5 == 0){
            return "Buzz";
        } else {
            return Integer.toString(number);
        }
    }
    public void counter() {
        for (int i = 1; i < 101; i++){
            String result = fizzBuzz(i);
            System.out.println(result);
        }
    }
}
