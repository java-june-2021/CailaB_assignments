package com.caila.dojosninjas.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.caila.dojosninjas.models.Dojo;
import com.caila.dojosninjas.services.DojoNinjaService;

@Controller
public class DojoController {
	@Autowired
	private final DojoNinjaService dnService;
	public DojoController(DojoNinjaService dnService) {
		this.dnService = dnService;
	}
	
	@RequestMapping("/dojo")
	public String Index(Model viewModel) {
		viewModel.addAttribute("dojos", dnService.getAllDojos());
		return "Index.jsp";
	}
	
	@RequestMapping("/dojo/{id}")
	public String Show(@PathVariable("id") Long id, Model viewModel) {
		viewModel.addAttribute("dojo", this.dnService.getOneDojo(id));
		return "DojoDisplay.jsp";
	}
	
	@RequestMapping("/dojo/create")
	public String NewDojo(@ModelAttribute("dojo") Dojo dojo) {
		return "NewDojo.jsp";
	}
	
	@RequestMapping(value="/adddojo", method=RequestMethod.POST)
	public String processDojo(@Valid @ModelAttribute("dojo") Dojo dojo, BindingResult result) {
		if(result.hasErrors())
			return "NewDojo.jsp";
		this.dnService.createDojo(dojo);
		return "redirect:/dojo";
	}
}
