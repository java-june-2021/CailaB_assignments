package com.caila.dojosninjas.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.caila.dojosninjas.models.Ninja;
import com.caila.dojosninjas.services.DojoNinjaService;

@Controller
public class NinjaController {
	@Autowired
	private DojoNinjaService dnService;
	public NinjaController(DojoNinjaService dnService) {
		this.dnService = dnService;
	}
	//do i need?
	@RequestMapping("/ninjas")
	public String Index(Model viewModel) {
		viewModel.addAttribute("ninjas", this.dnService.getAllNinjas());
		return "Index.jsp";
	}
//	
	@RequestMapping("/ninja/new")
	public String NewNinja(@ModelAttribute("ninja") Ninja ninja, Model viewModel) {
		viewModel.addAttribute("dojos", this.dnService.getAllDojos());
		return "NewNinja.jsp";
	}
	@RequestMapping(value="/addninja", method=RequestMethod.POST)
	public String processNinja(@Valid @ModelAttribute("ninja") Ninja ninja, BindingResult result, Model viewModel) {
		if(result.hasErrors()) {
			viewModel.addAttribute("dojos", this.dnService.getAllDojos());
			return "NewNinja.jsp";
		}
		this.dnService.createNinja(ninja);
		return "redirect:/";
	}
	
}
