package com.caila.dojosninjas.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caila.dojosninjas.models.Dojo;
import com.caila.dojosninjas.models.Ninja;
import com.caila.dojosninjas.repositories.DojoRepository;
import com.caila.dojosninjas.repositories.NinjaRepository;

@Service
public class DojoNinjaService {
	@Autowired
	private DojoRepository dRepository;
	@Autowired
	private NinjaRepository nRepository;
	
	public DojoNinjaService(DojoRepository dRepository, NinjaRepository nRepository) {
		this.dRepository = dRepository;
		this.nRepository = nRepository;
	}
	
	
	//create dojo
	public Dojo createDojo(Dojo dojo) {
		return dRepository.save(dojo);
	}
	
	//create ninja
	public Ninja createNinja(Ninja ninja) {
		return nRepository.save(ninja);
	}
	//get one dojo
	public Dojo getOneDojo(Long id) {
		return dRepository.findById(id).orElse(null);
	}
	// get all dojos
	public List<Dojo> getAllDojos(){
		return dRepository.findAll();
	}
	//get ninjas
	public List<Ninja> getAllNinjas(){
		return nRepository.findAll();
	}

}
