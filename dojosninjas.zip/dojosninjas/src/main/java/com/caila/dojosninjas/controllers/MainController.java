package com.caila.dojosninjas.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.caila.dojosninjas.services.DojoNinjaService;

@Controller
public class MainController {
	@Autowired
	private DojoNinjaService dnService;
	
	@RequestMapping("/")
	public String Index(Model viewModel) {
		viewModel.addAttribute("dojos", this.dnService.getAllDojos());
		return "Index.jsp";
	}
}