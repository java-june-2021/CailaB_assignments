package com.caila.authentication.services;

import java.util.List;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.caila.authentication.models.User;
import com.caila.authentication.repositories.UserRepository;

@Service
public class AuthenticationService {
	private final UserRepository uRepository;
	
	public AuthenticationService(UserRepository uRepository) {
		this.uRepository = uRepository;
	}
	// get all users
	public List<User> getAllUsers(){
		return this.uRepository.findAll();
	}
	// get one user
	public User getOneUser(Long id) {
		User user = this.uRepository.findById(id).orElse(null);
		return user;
	}
	// register the user. hash the password
	public User registerUser(User user) {
		//generate hash
		String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
		// set the hash password on the USER password field
		user.setPassword(hashed);
		//save the new password in the db with that object
		return uRepository.save(user);
	}
	
	//find user by email
	public User findByEmail(String email) {
		return uRepository.findByEmail(email);
	}
	// authenticate user
	public boolean authenticateUser(String email, String password) {
		// first find the user by their email
		User user = uRepository.findByEmail(email);
		// if unable to find by email return false
		if(user == null) {
			return false;
		} else {
			// if passwords match return true, else return false if in if
			if(BCrypt.checkpw(password, user.getPassword())) {
				return true;
			} else {
				return false;
			}
		}
	}
	
}
