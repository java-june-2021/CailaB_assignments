package com.caila.authentication.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.caila.authentication.models.User;
import com.caila.authentication.services.AuthenticationService;

@Controller
public class MainController {
	@Autowired
	private AuthenticationService aService;
	// show home page
	@GetMapping("/registration")
	public String index(@ModelAttribute("user") User user) {
		return "RegistrationPage.jsp";
	}
	// action register
//	@PostMapping("/register")
//	public String register(@Valid @ModelAttribute("User")User user, BindingResult result, HttpSession session) {
//		if(result.hasErrors()) {
//			// if validation errors kick back to index to try again and SEE errors
//			return "index.jsp";
//		}
//		User newUser = this.aService.registerUser(user);
//		session.setAttribute("user__id", newUser.getId());
//		return "redirect:/";
//	}


	
	//action register
	@PostMapping("/register")
	public String RegisterUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
		if(result.hasErrors()) {
			return "RegistrationPage.jsp";
		}
		User regUser = this.aService.registerUser(user);
		session.setAttribute("USERid", regUser.getId());
		return "redirect:/home";

	}
	// show login page
	@GetMapping("/login")
	public String login() {
		return "LoginPage.jsp";
	}
	// login action
	@PostMapping("/login")
	public String loginUser( @RequestParam("email") String email, @RequestParam("password") String password, Model viewModel, HttpSession session) {
		boolean isAuthenticated = aService.authenticateUser(email, password);
		if(isAuthenticated) {
			User returnUser = this.aService.findByEmail(email);
			session.setAttribute("USERid", returnUser.getId());
			return "redirect:/home";
		} else {
			viewModel.addAttribute("error", "Invalid Credentials. Check email and password and try again.");
			return "LoginPage.jsp";
		}

	}
	//home page
	@GetMapping("/home")
	public String home(HttpSession session, Model viewModel) {
		Long USERid = (Long) session.getAttribute("USERid");
		User ourUser = aService.getOneUser(USERid);
		viewModel.addAttribute("user", ourUser);
		return "HomePage.jsp";
	}
	//logout
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/registration";
	}
}
