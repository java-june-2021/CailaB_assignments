package com.caila.overflow.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caila.overflow.models.Answer;
import com.caila.overflow.models.Question;
import com.caila.overflow.models.Tag;
import com.caila.overflow.repositories.AnswerRepository;
import com.caila.overflow.repositories.QuestionRepository;
import com.caila.overflow.repositories.TagRepository;

@Service
public class OverflowService {
	@Autowired
	private AnswerRepository aRepository;
	@Autowired
	private QuestionRepository qRepository;
	@Autowired
	private TagRepository tRepository;
	
	// get one tag
	public Tag getOneTag(String subject) {
		return this.tRepository.findBySubject(subject);
	}
	
	//split tags want a string into an array
	public ArrayList<Tag> splitTag(String tags) {
		ArrayList<Tag> questionTags = new ArrayList<Tag>();
		String[] processTags = tags.split(", ");
		for(String subjectS : processTags) {
			// "if" is for if the tag already exists
			if(this.tRepository.existsBySubject(subjectS)) {
				Tag tagToAdd = this.getOneTag(subjectS);
				questionTags.add(tagToAdd);
			} else {
				// "else" is for if the tag doesn't exist, create and add
				Tag newTag = new Tag();
				newTag.setSubject(subjectS);
				this.tRepository.save(newTag);
				questionTags.add(this.getOneTag(subjectS));
			}
		}
		return questionTags;
	}
	
	// get one question
	public Question getOneQuestion(Long id) {
		return this.qRepository.findById(id).orElse(null);
	}
	// get all questions
	public List<Question> getAllQuestions(){
		return this.qRepository.findAll();
	}
	
	// create question
	public Question createQuestion(Question question) {
		question.setTags(this.splitTag(question.getFEtags()));
		return this.qRepository.save(question);
	}
	// create answer
	public Answer createAnswer(Answer answer) {
		return this.aRepository.save(answer);
	}
	
}
