package com.caila.prodcat.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.caila.prodcat.models.Category;
import com.caila.prodcat.models.Product;

public interface ProductRepository extends CrudRepository<Product, Long>{
	List<Product> findAll();
	//find categories that this product hasn't used
	List<Product> findByCategoriesNotContains(Category category);
}
