package com.caila.prodcat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdCatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdCatApplication.class, args);
	}

}
