package com.caila.prodcat.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caila.prodcat.models.Category;
import com.caila.prodcat.models.Product;
import com.caila.prodcat.repositories.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository pRepository;

	
	//get all products
	public List<Product> getAllProducts(){
		return this.pRepository.findAll();
	}
	// get one product
	public Product getOneProduct(Long id) {
		return this.pRepository.findById(id).orElse(null);
	}
	// create product
	public Product createProduct(Product product) {
		return this.pRepository.save(product);
	}
	// update product
	public Product updateProduct(Product product) {
		return this.pRepository.save(product);
	}
	// get list of categories not used by product
	public List<Product> getUnusedCategory(Category category){
		return this.pRepository.findByCategoriesNotContains(category);
	}
	// add category
	public Product addCatToProd(Product product, Category category) {
		List<Category> categories = product.getCategories();
		categories.add(category);
		return pRepository.save(product);
	}
}
