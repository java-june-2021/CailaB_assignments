package com.caila.prodcat.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caila.prodcat.models.Category;
import com.caila.prodcat.models.Product;
import com.caila.prodcat.repositories.CategoryRepository;

@Service
public class CategoryService {
	@Autowired
	private CategoryRepository cRepository;
	
	// get all categories
	public List<Category> getAllCategories(){
		return this.cRepository.findAll();
	}
	// get one category
	public Category getOneCategory(Long id) {
		return this.cRepository.findById(id).orElse(null);
	}
	// create category
	public Category createCategory(Category category) {
		return this.cRepository.save(category);
	}
	// update category
	public Category updateCategory(Category category) {
		return this.cRepository.save(category);
	}
	// get categories not added to the product
	public List<Category> unAddedCategories(Product product){
		return this.cRepository.findByProductsNotContains(product);
	}
	//add product
	public Category addProdToCat(Category category, Product product) {
		List<Product> products = category.getProducts();
		products.add(product);
		return this.cRepository.save(category);
	}
}
