package com.caila.prodcat.repositories;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.caila.prodcat.models.Category;
import com.caila.prodcat.models.Product;

public interface CategoryRepository extends CrudRepository<Category, Long>{
	List<Category> findAll();
	// find products that haven't been already sorted into this category
	List<Category> findByProductsNotContains(Product product);
}
