package com.caila.prodcat.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.caila.prodcat.models.Category;
import com.caila.prodcat.models.Product;
import com.caila.prodcat.services.CategoryService;
import com.caila.prodcat.services.ProductService;

@Controller
public class MainController {
	@Autowired
	private CategoryService cService;
	@Autowired
	private ProductService pService;
	
	//add product page
	@GetMapping("/product/new")
	public String AddProduct(@ModelAttribute("product") Product product) {
		return "NewProduct.jsp";
	}
	//add product action
	@PostMapping("/addproduct")
	public String CreateProduct(@Valid @ModelAttribute("product") Product product, BindingResult result) {
		if(result.hasErrors()) {
			return "NewProduct.jsp";
		}
		pService.createProduct(product);
		return "redirect:/product/new";
	}
	// show product page
	@GetMapping("/product/{id}")
	public String showProduct(@PathVariable("id") Long id, Model viewModel) {
		Product product = this.pService.getOneProduct(id);
		viewModel.addAttribute("product", product);
		List<Category> unusedCats = this.cService.unAddedCategories(product);
		viewModel.addAttribute("unusedCats", unusedCats);
		List<Category> categories = product.getCategories();
		return "ShowProduct.jsp";
	}

	
	//add category page
	@GetMapping("/category/new")
	public String AddCategory(@ModelAttribute("category") Category category) {
		return "NewCategory.jsp";
	}
	// add category ACTION
	@PostMapping("/addcategory")
	public String CreateCategory(@Valid @ModelAttribute("category") Category category, BindingResult result) {
		if(result.hasErrors()) {
			return "NewCategory.jsp";
		}
		cService.createCategory(category);
		return "redirect:/category/new";
	}
	//show category
	@GetMapping("/category/{id}")
	public String showCategory(@PathVariable("id") Long id, Model viewModel) {
		Category category = this.cService.getOneCategory(id);
		List<Product> products = category.getProducts();
		viewModel.addAttribute("category", category);
		viewModel.addAttribute("products", products);
		List<Product> unAdded = this.pService.getUnusedCategory(category);
		viewModel.addAttribute("unAdded", unAdded);
		return "ShowCategory.jsp";
	}
	//show product add category
	@PostMapping("/category/{id}")
	public String addACategory(@RequestParam("id") Long id, @PathVariable("id") Long id, Model viewModel) {
		Category category = this.cService.getOneCategory(id);
		Product product = this.pService.getOneProduct(id);
		this.cService.addProdToCat(category, product);
		return "redirect;/category/{id}";
	}
}
