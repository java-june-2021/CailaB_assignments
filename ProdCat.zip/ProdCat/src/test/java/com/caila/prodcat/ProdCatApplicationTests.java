package com.caila.prodcat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProdCatApplicationTests {

	@Test
	void contextLoads() {
	}

}
