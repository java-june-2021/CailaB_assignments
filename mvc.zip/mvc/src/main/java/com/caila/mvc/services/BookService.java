package com.caila.mvc.services;

import java.util.List;
//import java.util.Optional;

import org.springframework.stereotype.Service;

import com.caila.mvc.models.Book;
import com.caila.mvc.repositories.BookRepository;

@Service
public class BookService {
	//initialize the books variable with values
	private final BookRepository bookRepository;
    
    public BookService(BookRepository bookRepo) {
        this.bookRepository = bookRepo;
    }
    // returns all the books
    public List<Book> allBooks() {
        return this.bookRepository.findAll();
    }
    //return one book
    public Book getOneBook(Long id) {
    	return this.bookRepository.findById(id).orElse(null);
    }
    
    // creates a book
    public Book createBook(Book book) {
        return this.bookRepository.save(book);
    }
    // manual create book
    public Book userBook(String title, String description, String language, int numberOfPages) {	
    	Book newBook = new Book(title, description, language, numberOfPages);
    	return this.bookRepository.save(newBook);
    }
    
    //update
    public Book updateBook(Book book) {
    	return this.bookRepository.save(book);
    }
    
    // retrieves a book also
//    public Book findBook(Long id) {
//        Optional<Book> optionalBook = bookRepository.findById(id);
//        if(optionalBook.isPresent()) {
//            return optionalBook.get();
//        } else {
//            return null;
//        }
//    }
    //deletes a book
    public void deleteBook(Long id) {
    	this.bookRepository.deleteById(id);
    }

}
