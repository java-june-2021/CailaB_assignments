package com.caila.mvc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.caila.mvc.models.Book;
import com.caila.mvc.services.BookService;

@RestController
@RequestMapping("/api")
public class ApiController {
	@Autowired
	private BookService bService;
	
	@GetMapping("")
	public List<Book> allBooks(){
		return this.bService.allBooks();
	}
	@GetMapping("/{id}")
	public Book getOneBook(@PathVariable("id") Long id) {
		return this.bService.getOneBook(id);
	}
	@PostMapping("/create")
	public Book createBook(Book newBook) {
		return this.bService.createBook(newBook);
	}
	@PutMapping("/update/{id}")
	public Book editBook(@PathVariable("id") Long id, Book updatedBook) {
		return this.bService.updateBook(updatedBook);
	}
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable("id")Long id) {
		this.bService.deleteBook(id);
	}
	
//	private final BookService bookService;
//	
//	public MainController(BookService bookService) {
//		this.bookService = bookService;
//	}
//	@RequestMapping("/books")
//	public String index(Model model) {
//		List<Book> books = bookService.allBooks();
//		model.addAttribute("books", books);
//		return "index.jsp";
//	}
//	@RequestMapping("/books/{index}")
//	public String findBookByIndex(Model model, @PathVariable("index") Long index) {
//		Book book = bookService.findBook(index);
//		model.addAttribute("book", book);
//		return "showBook.jsp";
//	}
}
