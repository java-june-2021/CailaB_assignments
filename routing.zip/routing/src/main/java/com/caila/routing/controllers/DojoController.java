package com.caila.routing.controllers;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DojoController {
	@RequestMapping("/dojo")
	public String dojo() {
		return "This dojo is awesome!";
	}
	@RequestMapping("/dojo/{location}")
	public String dojoLocation(@PathVariable("location") String location) {
		switch(location) {
		case "Burbank":
			return "Burbank Dojo is located in Southern California";
		case "San-Jose":
			return "San Jose Dojo is the head quarters.";
		default:
			return String.format("%s is an awesome dojo", location);
		}
	}
}
