package com.caila.license.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.caila.license.models.License;
import com.caila.license.models.Person;
import com.caila.license.services.DriverLicenseService;



@Controller
public class MainController {

	@Autowired
	private DriverLicenseService dlService;
//	public MainController(DriverLicenseService service) {
//		this.dlService =service;
//	}
	
	@RequestMapping("/")
	public String index(Model viewModel) {
		viewModel.addAttribute("persons", this.dlService.getAllPersons());
		return "index.jsp";
	}
//	@GetMapping("/person")
//	public String Index(Model viewModel, @ModelAttribute("license") License license) {
//		viewModel.addAttribute("persons", this.dlService.getAllPersons());
//		
//	return "Person.jsp";
//	}
	@RequestMapping("/person/new")
	public String newPerson(@ModelAttribute("person") Person person) {
		return "Person.jsp";
	}

	@RequestMapping(value="/new", method=RequestMethod.POST)
	public String processPerson(@Valid @ModelAttribute("person") Person person, BindingResult result) {
		if(result.hasErrors()) {
			return "Person.jsp";
		}
		this.dlService.createPerson(person);
		return "redirect:/";
	}
	
	@RequestMapping("/license/create")
	public String createLicense(@ModelAttribute("license") License license, Model viewModel) {
		viewModel.addAttribute("ulPersons", this.dlService.getUnlicensedPeople());
		return "License.jsp";
	}
	@RequestMapping(value="/addlicense", method=RequestMethod.POST)
	public String processLicense(@Valid @ModelAttribute("license") License license, BindingResult result, Model viewModel) {
		if(result.hasErrors()) {
			viewModel.addAttribute("ulPersons", this.dlService.getUnlicensedPeople());
			return "License.jsp";
		}
		this.dlService.createLicense(license);
		return "redirect:/";
	}
	@RequestMapping("/{id}")
	public String show(Model viewModel, @PathVariable("id") Long id) {
		viewModel.addAttribute("person", this.dlService.getOnePerson(id));
		return "Show.jsp";
	}

}
