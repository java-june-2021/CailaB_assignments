package com.caila.license.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.caila.license.models.Person;

@Repository
public interface PersonRepository extends CrudRepository<Person, Long>{
	List<Person>findAll();
	
	
	
//	List<Person> findByNoLicense();
	
	List<Person> findByLicenseIdIsNull();
//	Person save(Person person);
	
	
}
