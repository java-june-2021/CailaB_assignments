package com.caila.license.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.caila.license.models.License;
import com.caila.license.models.Person;
import com.caila.license.repositories.LicenseRepository;
import com.caila.license.repositories.PersonRepository;

@Service
public class DriverLicenseService {
	
	@Autowired
	private PersonRepository pRepository;
	@Autowired
	private LicenseRepository lRepository;
	
//	private final PersonRepository pRep;
//	private final LicenseRepository lRep;
//	
//	public DriverLicenseService(PersonRepository pRep, LicenseRepository lRep) {
//		this.pRep = pRep;
//		this.lRep = lRep;
//	}
	public int generateLicenseNumber() {
		License lic = this.lRepository.findTopByOrderByNumberDesc();
		if(lic == null) {
			return 1;
		}
		int previousLicenseNum = lic.getNumber();
		previousLicenseNum++;
		return (previousLicenseNum);
	}
	public Person getOnePerson(Long id) {
		return pRepository.findById(id).orElse(null);
	}
	public List<Person> getAllPersons(){
		return pRepository.findAll();
	}
	public List<Person> getNewPeople(){
		return pRepository.findByLicenseIdIsNull();
	}
//	
	//create person
	public Person createPerson(Person person) {
		return this.pRepository.save(person);
	}
	//create license
	public License createLicense(License license) {
		license.setNumber(this.generateLicenseNumber());
		return this.lRepository.save(license);
	}
	
	public List<Person> getUnlicensedPeople(){
		return this.pRepository.findByLicenseIdIsNull();
	}
	

	
	
}
