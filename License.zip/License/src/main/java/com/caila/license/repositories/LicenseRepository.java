package com.caila.license.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.caila.license.models.License;


@Repository
public interface LicenseRepository extends CrudRepository<License, Long>{
	public List<License>findAll();
	
	public License findTopByOrderByNumberDesc();
	
//	License save(License license);

}
