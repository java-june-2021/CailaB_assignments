package com.caila.license;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicenseApplicationTests {

	@Test
	void contextLoads() {
	}

}
