package com.caila.overflow.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.caila.overflow.models.Answer;
import com.caila.overflow.models.Question;
import com.caila.overflow.services.OverflowService;
import com.caila.overflow.validators.TagValidator;

@Controller
public class MainController {
	@Autowired
	private OverflowService oService;
	@Autowired
	private TagValidator tValidator;
	

	// main question page retrieve
	@GetMapping("/questions")
	public String index(Model viewModel) {
		viewModel.addAttribute("allQs", this.oService.getAllQuestions());
		return "ShowQuestions.jsp";
	}
	// make a new question page
	@GetMapping("/newquestion")
	public String newQuestion(@ModelAttribute("question") Question question) {
		return "NewQuestion.jsp";
	}
	@PostMapping("/askquestion")
	public String addQuestion(@Valid @ModelAttribute("question") Question question, BindingResult result) {
		tValidator.validate(question, result); //puts question with tags through the validator
		if(result.hasErrors()) {
			return "NewQuestion.jsp"; 
		}
		this.oService.createQuestion(question);
		return "redirect:/questions";
	}
	// show page
	@GetMapping("/question/{id}")
	public String showQuestion(@PathVariable("id") Long id, Model viewModel, @ModelAttribute("answer")Answer answer) {
		viewModel.addAttribute("question", this.oService.getOneQuestion(id));
		return "Answer.jsp";
	}
	// add answer
	@PostMapping("/addanswer")
	public String answerQuestion(@Valid @ModelAttribute("answer") Answer answer, BindingResult result, Model viewModel) {
		if(result.hasErrors()) {
			viewModel.addAttribute("question", this.oService.getOneQuestion(answer.getQuest().getId()));
			return "Answer.jsp";
		}
		this.oService.createAnswer(answer);
		return "redirect:/question/" + answer.getQuest().getId();
	}
	
}
