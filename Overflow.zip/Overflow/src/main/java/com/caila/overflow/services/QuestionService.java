package com.caila.overflow.services;

import org.springframework.stereotype.Service;

@Service
public class QuestionService {

}
